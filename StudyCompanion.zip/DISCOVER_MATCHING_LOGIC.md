# Discover Matching Logic

## Goal

`Discover` is not meant to behave like raw YouTube search.

It should:

1. understand the learner request
2. retrieve candidate videos from YouTube
3. understand what each video actually teaches from transcript when available, otherwise metadata
4. reject irrelevant or misleading videos early
5. rank only the candidates that match the learner's exact need

## Design Principles

### 1. Request first, refinements second

The raw learner request is the primary signal.

Optional UI choices like level, style, and duration are refinements, not required steps. They should narrow or re-rank the result set, not define the search from scratch.

### 2. Hard reject obvious junk

Before expensive analysis, reject content that clearly does not belong:

- animal/wildlife results for technical Python
- movie recap / entertainment content
- roadmap / review / opinion videos when the learner asked for direct teaching
- legacy React class-components content for modern React requests

### 3. Exact subtype matters

A request like `Build a web scraper in Python` is not just `python` + `project`.

It is a project request with a project subtype:

- core subtype: `web scraping`
- supporting subtype concepts: `requests`, `beautiful soup`, `html parsing`

Generic Python project videos are not good enough. They must be filtered or down-ranked if they do not match the subtype.

### 4. Transcript > metadata, but metadata is still useful

When transcript is available:

- use transcript to infer concepts, difficulty, teaching style, clarity, and summary

When transcript is not available:

- use title, description, tags, and chapters
- lower confidence appropriately
- do not blindly reject metadata-only candidates if the metadata strongly indicates a valid teaching match

### 5. One matching policy everywhere

The same matching policy must be used in:

- live recommendation requests
- offline corpus evaluation
- scoring/ranking decisions

If these drift apart, offline passes become meaningless.

## Current Logic Flow

### Step 1: Build a structured user profile

Source:

- [`backend/src/services/recommendations/userUnderstander.js`](backend/src/services/recommendations/userUnderstander.js)

Output includes:

- normalized topic
- inferred intent
- goal
- must-have concepts
- avoid list
- preferred style
- duration constraints

Examples:

- `Python beginner course` -> topic `python programming`, intent `learn_basics`
- `React hooks explained` -> topic `react js`, intent `concept_clarity`, must-have `hooks`, `useState`, `useEffect`
- `Build a web scraper in Python` -> topic `python programming`, intent `build_project`, must-have `web scraping`, `requests`, `beautiful soup`, `scraper`

### Step 2: Generate search queries

Source:

- [`backend/src/services/recommendations/queryGenerator.js`](backend/src/services/recommendations/queryGenerator.js)

Logic:

- generate broad topic queries
- add level-specific variants
- add style-specific variants
- add concept-specific variants
- for project requests, add subtype-focused queries

Example for scraper requests:

- `python web scraping tutorial`
- `python web scraper project`
- `python web scraping build from scratch`
- `python beautiful soup tutorial`
- `python requests beautiful soup tutorial`

### Step 3: Early policy filtering

Source:

- [`backend/src/services/recommendations/matchingPolicy.js`](backend/src/services/recommendations/matchingPolicy.js)

This is the first hard gate.

It checks:

- non-teaching content rejection
- tutorial signal
- intent match
- minimum topical relevance
- subtype match for exact project requests

Important example:

For `Build a web scraper in Python`, a candidate should not survive early filtering unless it matches enough scraper-specific concept groups.

### Step 4: Build a video profile

Source:

- [`backend/src/services/recommendations/videoUnderstander.js`](backend/src/services/recommendations/videoUnderstander.js)
- [`backend/src/services/recommendations/conceptSignals.js`](backend/src/services/recommendations/conceptSignals.js)

Transcript-backed path:

- chunk transcript
- infer concepts
- infer teaching style
- infer clarity and teaching quality

Metadata path:

- infer from title, description, tags, chapters
- estimate teaching quality heuristically
- lower confidence

Explicit concept-signal extraction now supplements token extraction for cases like:

- `web scraping`
- `beautiful soup`
- `requests`
- `hooks`
- `useState`
- `useEffect`
- `inner join`
- `left join`
- `promises`
- `async`
- `await`

This improves exact-match reasoning from transcript or metadata text.

### Step 5: Score the candidate

Source:

- [`backend/src/services/recommendations/matcher.js`](backend/src/services/recommendations/matcher.js)

Scoring dimensions include:

- topic match
- concept coverage match
- subtype fit
- goal fit
- difficulty match
- prerequisite compatibility
- teaching style match
- clarity fit
- teaching quality
- teaching effectiveness
- confidence bonus

Penalties include:

- outdated content
- avoid-concept overlap
- avoid-style overlap
- metadata-only penalty

### Step 6: Rank the surviving results

Source:

- [`backend/src/services/recommendations/ranker.js`](backend/src/services/recommendations/ranker.js)

Ranking:

- removes obviously weak candidates
- sorts by final score
- gives a small transcript boost

## What Changed In This Rewrite

### Shared matching policy

The early filtering logic was moved into a shared policy module so live requests and offline evaluation use the same rules.

### Exact project subtype enforcement

Project requests no longer treat all project videos as equivalent.

For scraper requests, subtype groups are enforced.

### Subtype-aware scoring

`matcher.js` now scores `subtypeFit` explicitly and uses it in:

- weighting
- reasons
- hard gating for project requests with must-have concepts

### Stronger content understanding

`videoUnderstander.js` now augments extracted concepts with explicit concept-signal detection from transcript/metadata text.

## What Still Needs Live Validation

Offline evaluation is necessary, but not enough.

Live validation is still needed for:

- real YouTube retrieval noise
- quota behavior
- transcript availability variance
- ranking under real candidate pools

The remaining live benchmark queries are:

- `Python beginner course`
- `React hooks explained`
- `Build a web scraper in Python`
- `SQL joins explained`
- `JavaScript promises explained`

## Definition of Done

`Discover` should be considered done only when:

1. the benchmark queries return the right type of results live
2. irrelevant videos are consistently rejected
3. exact project and concept requests stop leaking generic content
4. the same logic is validated offline and live
5. the user does not need to fight the UI or questionnaire to get useful recommendations
