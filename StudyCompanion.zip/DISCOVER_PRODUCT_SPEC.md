# Discover Product Spec

## Purpose

`Discover` is not a general YouTube search box.

`Discover` is a learning-video matching system inside Study Companion. Its job is to understand what a student wants to learn, understand what candidate videos actually teach, and recommend the best educational matches.

The feature should reduce the amount of manual searching a student has to do.

## Product Promise

When a student describes what they want to learn, `Discover` should:

1. collect candidate videos from YouTube
2. analyze what each video is really about
3. understand the student's learning need
4. filter out irrelevant or low-value content
5. rank the strongest educational matches

The result should feel like a study assistant, not a basic keyword search.

## In Scope

- learner-intent understanding
- educational-video retrieval
- transcript-aware and metadata-aware video analysis
- relevance filtering
- ranking based on learning fit
- user-friendly recommendation presentation

## Out of Scope

- trending-video discovery
- entertainment recommendations
- social recommendation features
- general YouTube browsing
- non-educational content exploration

## Core User Goal

The student should not need to manually inspect dozens of videos to figure out:

- whether the video is really about the requested topic
- whether it is beginner-friendly or advanced
- whether it is project-based or explanation-based
- whether it matches the student’s goal

`Discover` should do that work for them.

## Primary User Inputs

The learner provides:

- topic or request
- current level
- goal
- preferred teaching style
- time limit if any
- what they already know
- what they want to avoid

## Primary System Inputs

The system may use:

- YouTube title
- YouTube description
- YouTube tags or keywords when available
- transcript when available
- basic video metadata such as duration and channel name

## Required Output Qualities

Every recommendation should aim to be:

- educational
- relevant to the stated request
- aligned with learner level
- aligned with learner goal
- aligned with teaching style when possible
- free of obvious junk or unrelated content

## Non-Negotiable Quality Rules

`Discover` must reject obvious mismatches for learning requests, including:

- animal videos for technical terms like `python`
- movie recaps
- entertainment-only clips
- trailers
- unrelated news
- generic low-signal content with weak educational value

`Discover` must not return irrelevant results only to avoid an empty state.

Quality is more important than filling the screen with weak matches.

## Request Types

`Discover` must recognize at least these request types.

### 1. Broad Exploration

Example:
- `python`
- `react`
- `sql`

Meaning:
- the student wants a starting point but has not specified a narrow subtopic yet

Expected behavior:
- prefer foundational educational content
- prefer structured, beginner-safe overviews unless learner level suggests otherwise
- avoid niche deep-dive content unless strongly justified

Expected results:
- high-quality introductions
- beginner courses
- foundational explanations

### 2. Learn Basics

Example:
- `python basics`
- `learn sql for beginners`
- `javascript beginner course`

Meaning:
- the student explicitly wants fundamentals

Expected behavior:
- prioritize beginner-friendly structure
- prefer clear explanation and low prerequisite load
- reject advanced or highly specialized content

Expected results:
- fundamentals
- beginner tutorials
- crash courses only if they are truly beginner-safe

### 3. Build Project

Example:
- `build a web scraper in python`
- `react todo app tutorial`
- `build a portfolio in html css js`

Meaning:
- the student wants practical implementation help

Expected behavior:
- extract must-have project concepts
- prioritize hands-on walkthroughs
- prefer project-based teaching
- reject purely conceptual or overly generic results

Expected results:
- build-from-scratch videos
- project walkthroughs
- practical implementation tutorials

### 4. Concept Clarity

Example:
- `react hooks explained`
- `sql joins explained`
- `python decorators concept`

Meaning:
- the student wants understanding, not just code copying

Expected behavior:
- prioritize explanation quality
- prefer concept-first teaching
- prefer videos that explain what, why, and when
- reject flashy project content that barely teaches the concept

Expected results:
- explanation-first videos
- concept tutorials
- clear mental-model content

## Topic Disambiguation Rules

`Discover` must disambiguate ambiguous technical words toward the learning domain by default.

Examples:

- `python` means `python programming` unless the user clearly indicates wildlife, animals, or biology
- `react` means `React.js`
- `sql` means database/query learning
- `java` means programming unless clearly coffee or geography-related

If the user explicitly asks for a non-technical meaning, the system may follow that request.

## Video Understanding Requirements

For each candidate video, `Discover` should try to infer:

- main topic
- subtopics or concepts covered
- learner level
- teaching style
- whether it is educational
- whether it is project-based or concept-based
- likely usefulness for this student

Transcript use:

- if a usable transcript exists, it should improve understanding
- if transcript quality is weak or missing, metadata may be used
- metadata-only analysis must be treated with lower confidence than transcript-backed analysis

## Ranking Principles

Ranking should prioritize:

1. relevance to the learner’s request
2. educational value
3. learner level fit
4. goal fit
5. teaching style fit
6. concept coverage

Ranking should not prioritize:

- popularity alone
- keyword overlap alone
- title clickbait

## Result Diversity

When multiple strong results exist, `Discover` should avoid returning near-duplicates if they teach the same thing in the same way.

It is acceptable to show variety when that improves learning choice, for example:

- one clear beginner explanation
- one practical project-based video
- one deeper follow-up

## Empty State Policy

If no strong educational match exists, `Discover` should:

- tell the user clearly
- suggest how to refine the request

It must not:

- return irrelevant videos just to populate the list
- pretend weak matches are strong matches

## Example Behavior

### Request: `python beginner course`

Should prefer:
- beginner Python programming tutorials
- foundations and structured learning videos

Should reject:
- snake videos
- movie content
- advanced optimization deep dives

### Request: `python concepts`

Should prefer:
- concept-based Python learning content
- explanation-first tutorials

Should reject:
- entertainment and unrelated content
- generic filler that only matches the word `python`

### Request: `build a web scraper in python`

Should prefer:
- Python scraping tutorials
- project-based walkthroughs
- requests/Beautiful Soup type videos

Should reject:
- generic Python intros with no scraping
- unrelated backend tutorials

### Request: `react hooks explained`

Should prefer:
- explanation-first hooks videos
- conceptual React teaching

Should reject:
- project videos where hooks are only incidental
- outdated React material

## User Experience Requirements

User-facing copy should be:

- simple
- helpful
- non-technical

The user should not see:

- internal debug data
- scoring internals
- raw algorithm language

## Success Criteria

`Discover` is behaving correctly when:

- broad technical topics return educational results, not unrelated content
- project requests return practical project content
- concept requests return explanation-first content
- beginner requests return beginner-safe material
- irrelevant results are consistently blocked
- the system helps the user narrow choices instead of forcing manual video inspection

## Failure Criteria

`Discover` is failing when:

- a user asks for a learning topic and gets unrelated content
- good educational videos are consistently missing
- broad topics return zero useful results
- low-quality fallback content appears
- the user must still manually inspect many weak videos

## Implementation Guidance

This document defines product behavior only.

It does not prescribe a specific algorithm, database design, or ranking implementation.

Any implementation is acceptable as long as it satisfies the behavior defined here.
