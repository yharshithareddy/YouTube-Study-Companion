# Discover Real Corpus Plan

## Purpose

This phase moves `Discover` from a small mock dataset toward a real evaluation corpus built from actual YouTube-style video records.

The goal is not to hit live APIs during every test run. The goal is to collect a reusable local corpus of real candidate videos, transcripts when available, extracted analysis, and expected labels so the recommendation system can be evaluated on meaningful data.

## Why This Phase Exists

The mock dataset is useful for guarding product rules, but it cannot prove that the system understands real educational video content.

To validate the actual recommendation pipeline, the project needs:

- real video metadata
- transcript text when available
- analysis derived from actual content
- labels describing which videos are good, weak, or wrong for a learner request

## Corpus Design

The real corpus is organized under `data/discover/`.

### 1. Video Records

Stored in `data/discover/corpus/real-videos.sample.json`

Each record should represent one real candidate video and include:

- source metadata
- title
- description
- tags
- channel information
- duration
- transcript availability
- local transcript file path when stored
- local analysis file path when stored

### 2. Transcript Records

Stored in `data/discover/transcripts/`

Each transcript file should contain:

- the transcript text
- transcript source
- quality notes
- language
- whether it is human-made or auto-generated

### 3. Analysis Records

Stored in `data/discover/analysis/`

Each analysis file should contain normalized extracted features, such as:

- inferred topic
- concepts covered
- learner level
- teaching style
- educational intent
- confidence
- summary of what the video actually teaches

### 4. Request Labels

Stored in `data/discover/labels/requests.sample.json`

These labels connect learner requests to videos and specify:

- should rank high
- acceptable but weaker
- should reject
- reasons for the label

## Evaluation Goal

The corpus should eventually support tests like:

- given `Python beginner course`, rank strong educational beginner videos above weak or irrelevant ones
- given `React hooks explained`, prefer explanation-first hooks content over project-only or outdated videos
- given `build a web scraper in Python`, prefer project walkthroughs using scraping concepts

## What This Phase Does Not Do

This phase does not:

- solve the recommendation algorithm by itself
- fetch live data automatically
- claim that the current ranking is good enough

It creates the structure needed to evaluate the algorithm against real content instead of only mock examples.

## Recommended Corpus Growth Plan

### Stage 1

Collect 50 real videos across core topic families:

- Python
- React
- SQL
- JavaScript

### Stage 2

Expand to 150 to 300 videos with:

- more request diversity
- more transcript availability variation
- edge cases
- low-quality distractors

### Stage 3

Add labels for:

- broad exploration
- beginner learning
- project-based requests
- concept-clarity requests

## Minimum Quality Requirements For Stored Data

Each real video record should have:

- title
- description
- tags if available
- duration
- channel title
- transcript availability flag
- transcript path if captured
- manual or automated analysis path

Each labeled request should have:

- the learner request
- expected request type
- expected topic
- expected good matches
- expected rejects

## Success Criteria For This Phase

This phase is complete when the repository has:

- a stable folder structure for real corpus data
- a schema for real video records
- a schema for request labels
- sample transcript and analysis files
- sample real-style corpus entries that show how future data should be stored

## Next Phase After This

After this phase, the next implementation step should be:

- build a corpus loader
- validate schema shape
- run offline ranking against real stored corpus items
- then redesign the algorithm using those results
